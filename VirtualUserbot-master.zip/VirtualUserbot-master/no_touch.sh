echo 'Hmlo, Updating Requirements'
pip3 install -r requirements.txt
python3 -m virtualuserbot
echo 'Me iz Doge.'
