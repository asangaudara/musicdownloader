from virtualuserbot import CMD_HELP

CMD_HELP.update(
    {
        "Language": "**Language :** Change the Bot's Language\
    \n\n📌** CMD ★** `.set var lang en`\
    \n**USAGE   ★  **Change the Bot's Language to English (Standard)\
    \n\n📌** CMD ★** `.set var lang si`\
    \n**USAGE   ★  **Change the Bot's Language to Sinhala (Sinhalese)"
    }
)
