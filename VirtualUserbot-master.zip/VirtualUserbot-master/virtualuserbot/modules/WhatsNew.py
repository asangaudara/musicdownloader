from virtualuserbot import CMD_HELP

CMD_HELP.update(
    {
        "Whats New": """**Mini Update 3.1 :** VirtualUserbot New features
        Fixed the Errors.
        
        ** Errors and Bug Fixes **
        No errors anymore.. All logging features running now
        
        ** Custom Emoji on Help **
        `.set var EMOJI_TO_DISPLAY_IN_HELP <emoji>`
               
        ** Stickers Improovements **
        Kang any Media
              
        ** New qbot **
        `.qbot` to create quotes
        
        ** Plus More **
        PM Protection done right. Translation also done right
        
        ** Many Bug Fixes **       
"""
    }
)
