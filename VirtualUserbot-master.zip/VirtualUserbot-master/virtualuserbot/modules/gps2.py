import re

from geopy.geocoders import Nominatim
from telethon.tl import types

from virtualuserbot import CMD_HELP, bot

from ..utils import admin_cmd


@borg.on(admin_cmd(pattern="locate ?(.*)"))
async def gps(event):
    if event.fwd_from:
        return
    reply_to_id = event.message
    if event.reply_to_msg_id:
        reply_to_id = await event.get_reply_message()
    input_str = event.pattern_match.group(1)

    if not input_str:
        return await event.edit("what should i find give me location.")

    await event.edit("finding")

    geolocator = Nominatim(user_agent="LOCATER")
    geoloc = geolocator.geocode(input_str)

    if geoloc:
        lon = geoloc.longitude
        lat = geoloc.latitude
        await reply_to_id.reply(
            input_str, file=types.InputMediaGeoPoint(types.InputGeoPoint(lat, lon))
        )
        await event.delete()
    else:
        await event.edit("i coudn't find it")


IF_EMOJI = re.compile(
    "["
    "\U0001F1E0-\U0001F1FF"  # flags (iOS)
    "\U0001F300-\U0001F5FF"  # symbols & pictographs
    "\U0001F600-\U0001F64F"  # emoticons
    "\U0001F680-\U0001F6FF"  # transport & map symbols
    "\U0001F700-\U0001F77F"  # alchemical symbols
    "\U0001F780-\U0001F7FF"  # Geometric Shapes Extended
    "\U0001F800-\U0001F8FF"  # Supplemental Arrows-C
    "\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs
    "\U0001FA00-\U0001FA6F"  # Chess Symbols
    "\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A
    "\U00002702-\U000027B0"  # Dingbats
    "]+"
)


def deEmojify(inputString: str) -> str:
    """Remove emojis and other non-safe characters from string"""
    return re.sub(IF_EMOJI, "", inputString)


@borg.on(admin_cmd(pattern="map(?: |$)(.*)"))
async def nope(doit):
    ok = doit.pattern_match.group(1)
    if not ok:
        if doit.is_reply:
            (await doit.get_reply_message()).message

            return
    mappy = await bot.inline_query("openmap_bot", f"{(deEmojify(ok))}")
    await mappy[0].click(
        doit.chat_id,
        reply_to=doit.reply_to_msg_id,
        silent=True if doit.is_reply else False,
        hide_via=True,
    )
    await doit.delete()


CMD_HELP.update(
    {
        "location finder": "__**PLUGIN NAME :** gps__\
    \n\n📌** CMD ★** `.locate <location>`\
    \n**USAGE   ★  **Finds your desired location using geopy...\
    \n\n📌** CMD ★** `.map <location>`\
    \n**USAGE   ★  **Uses an inline bot to find your desired location.."
    }
)
